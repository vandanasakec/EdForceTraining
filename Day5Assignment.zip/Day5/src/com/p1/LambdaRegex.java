package com.p1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class LambdaRegex {


	    public static void main(String[] args) {

	        String input = "ANother input with special characters : ! @ # $ % ^ & * ( ) ";

	        List<Character> vowels = new ArrayList<>(Arrays.asList('a', 'e', 'i', 'o', 'u'));
	        input = input.toLowerCase();

	        long countVowels = 0;
	        long countCOnsonants = 0;
	        long countSpecialChar = 0;
	        long countSpaces = 0;

	        countVowels = input.chars().filter(curretChar -> vowels.contains((char) curretChar)).count();

	        countCOnsonants = input.chars().filter(curretChar -> !vowels.contains((char) curretChar))
	                .filter(nonVowelCh -> (nonVowelCh >= 'a' && nonVowelCh <= 'z')).count();
	     // 2. Remove special chars using regex
	     //   List<String> stringList = input.t.map(str -> str.replaceAll("[^a-zA-Z0-9]", ""))
	           //     .collect(Collectors.toList());
	        input.chars().filter(curretChar -> !vowels.contains((char) curretChar)).
    		filter(nonVowelCh -> !(nonVowelCh >= 'a' && nonVowelCh <= 'z'))
            .forEach(System.out::println);
	        countSpaces = input.chars().filter(curretChar -> !vowels.contains((char) curretChar))
	                .filter(nonVowelCh -> (nonVowelCh >= 'a' && nonVowelCh <= 'z')).count();
	        System.out.println("Total count of vowels : " + countVowels);
	        System.out.println("Total count of consonants : " + countCOnsonants);
	        System.out.println("Total count of SpecialChar : " + countSpecialChar);

	       
	    }
	}

