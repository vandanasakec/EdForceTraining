package TestEdForce;

class PrintChar1 implements Runnable{
public void run(){
for(int i=0;i<MyThreadRunnable.str.length();i++){
System.out.println("Child Thread..."+MyThreadRunnable.str.charAt(MyThreadRunnable.cindex++));
try {
	Thread.sleep(50);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}}
}
public class MyThreadRunnable {
static String str = "Hello, am explroign mutlithreadin g...";
static int cindex = 0;
public static void main(String[] args) throws InterruptedException {
	
PrintChar1 pc = new PrintChar1();
pc.run();
for(;cindex<str.length();){
System.out.println("Main Thread..."+str.charAt(cindex++));
Thread.sleep(50);}}}
