package TestEdForce;

class Account{
	String accName;
	Address address;
	public Account(){
		
	}
	public Account(String accName, Address address) {
		super();
		this.accName = accName;
		this.address = address;
	}
	public String getAccName() {
		return accName;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	  @Override
	    protected Object clone() throws CloneNotSupportedException {
	        // this will make  a shallow copy............................
	        return super.clone();
	    }

}
public class DeepCopyDemo {
	public static void main(String[] args) throws CloneNotSupportedException
	{
		//deep copy
		 Address model = new Address();
	        model.setCity("New Delhi");
	        model.setCountry("India");;

	        System.out.println(model);

	        // now assigning model to another object..
	        Address referenceCopty = model;    // reference copy..
	        System.out.println(referenceCopty.getCity());

	        // making changes in one object..
	        model.city = "Old Delhi";
	        System.out.println(referenceCopty.getCity());
	        System.out.println(model.getCity());
	        
	        
	        //shallow

	        Account model1 = new Account();

	        Address address = new Address();
	        address.setCity("New Delhi");
	        address.setCountry("India");

	        model1.setAccName("Samriti");

	        System.out.println(""+model1.getAccName());

	        Account model2 = (Account) model1.clone();

	      //  model1.setAccName("Samriti1");  
	        address.setCity("Old Delhi");
	        System.out.println("Shalloe"+model2.getAccName());



	}
}
