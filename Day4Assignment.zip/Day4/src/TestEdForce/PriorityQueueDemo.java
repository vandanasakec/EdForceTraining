package TestEdForce;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.PriorityQueue;

public class PriorityQueueDemo{
	 public static void main(String[] args) {
		 PriorityQueue<String> pq = new PriorityQueue<>((c1,c2)->c1.length()-c2.length());
		pq.offer("ABC");
		pq.offer("ABCD");pq.offer("ABCDE");pq.offer("ABCDEF");pq.offer("ABCDEFG");pq.offer("ABC");
		System.out.println("Prioroty queue is"+pq);
		//pq.poll();
		pq.peek();
		Iterator<String> itr=pq.iterator();
		while(itr.hasNext())
		{
			System.out.println("after length"+itr.next());
		}
}}