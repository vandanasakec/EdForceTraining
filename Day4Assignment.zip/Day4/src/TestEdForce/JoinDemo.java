package TestEdForce;

class PrintChar3 extends Thread{

PrintChar3(String tname){
	setName(tname);
}
public void run(){
	for(int i=0;i<MyThread.str.length();i++){
		System.out.println(Thread.currentThread().getName()+" Thread..."+MyThread.str.charAt(MyThread.cindex++));
		try {
			Thread.sleep(60);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}}}


public class JoinDemo{
	static String str = "Hello, am explroign mutlithreadin g...";static int cindex = 0;
public static void main(String[] args) throws InterruptedException{
	PrintChar3 pc1 = new PrintChar3("Beta");
pc1.start();
PrintChar3 pc2 = new PrintChar3("Gamma");
pc2.start();
pc1.join();
pc2.join();
System.out.println("-------------------");
System.out.println(pc1.getState().name()+"|"+Thread.currentThread().getState().name());
}}




