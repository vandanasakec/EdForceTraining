package TestEdForce;


public class StaticInnerClassTest {

	public static void main(String[] args) {
	
	OuterClass1.InnerClass.invoke();
/*class Enr{
	
//class inside method
	}*/
	}

}
class OuterClass1{
	private static String name ="Samriti";
	public static class InnerClass{
		public static void invoke()
		{
			System.out.println("Called inner class by " +name);
		}
	}
}
