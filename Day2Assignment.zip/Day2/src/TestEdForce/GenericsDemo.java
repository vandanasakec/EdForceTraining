package TestEdForce;

public class GenericsDemo {
	public static void main(String[] args) {
	Parcel<String> parcel = new GenericParcel<String>();
	parcel.test();
	GenericParcel<String> parcel2 = new GenericParcel<String>();
	parcel2.test();
	Parcel<String> parcel3 = new Parcel<String>();
	parcel3.test();

}
}
class Parcel<T> {
	public void test()
	{
		System.out.println("base generic");
	}
}

class GenericParcel<T> extends Parcel<T> {
public void test()
{
	System.out.println("dervided generic");
}
}