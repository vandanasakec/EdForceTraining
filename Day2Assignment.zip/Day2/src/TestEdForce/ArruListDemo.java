package TestEdForce;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;

public class ArruListDemo {
	public static void main(String[] args) {
		
		ArrayList<String> data=new ArrayList<>();
		
		data.add("Samriti");

		data.add("Samriti1");
		data.add("Samriti2");
		data.add("Samriti3");
		data.add("Samriti4");
		data.add("Samriti5");
		data.add("Samriti6eee");
	
	HashSet<String> dataSet=new HashSet<>(data);
	String max_char=Collections.max(dataSet, new Comparator<String>(){

		@Override
		public int compare(String o1, String o2) {
			return o1.length()-o2.length();
		}
		
	});
	System.out.println("Max is"+max_char);
	
	//uisn lambda
	String max_char1=Collections.max(dataSet, (o1,o2)->o1.length()-o2.length());
		
		
	
	System.out.println("Max using lambda is"+max_char1);
	
	
}}
class 	MyComparator implements Comparator<String>{

	@Override
	public int compare(String o1, String o2) {
		return o1.length()-o2.length();
	}
	
}

