package TestEdForce;

public class Application {
	
	public void open() {
		System.out.println("Parent Open Method");
	}
	public void close(){
		System.out.println("Child Open Method");
	}
}
