package TestEdForce;

class MethodChaining1 {

	private int a;
	private float b;

	MethodChaining1() { System.out.println("Calling The Constructor"); }

	public MethodChaining1 setint(int a)
	{
		this.a = a;
		return this;
	}

	public MethodChaining1 setfloat(float b)
	{
		this.b = b;
		return this;
	}

	void display()
	{
		System.out.println("Display=" + a + " " + b);
	}
}

public class MethodChaining {
	public static void main(String[] args)
	{
		// This is the "method chaining".
		new MethodChaining1().setint(10).setfloat(20).display();
	}
}

