package TestEdForce;

public class AddressAggregation {

	String city, state, country;

	public AddressAggregation(String city, String state, String country) {
		this.city = city;
		this.state = state;
		this.country = country;
	}
}
