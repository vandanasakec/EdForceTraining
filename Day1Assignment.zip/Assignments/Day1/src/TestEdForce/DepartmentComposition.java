package TestEdForce;

public class DepartmentComposition {

    private UniversityComposition university;
 
    DepartmentComposition(UniversityComposition univ){
        this.university = univ;
    }
 
    public void destroy(){
        //It's aggregation here, if we fire any professor then they
        //will come out of department but they can still keep living
    }
}
