package TestEdForce;

public class Todo extends Application{
	public void open(){
		
		System.out.println("TodoApp.open()");
		}
		
	public	void close(){
		System.out.println("TodoApp.close()");
		}
	
	public static void main(String[] args)
	{
		Application app=new Todo();
		app.close();
		app.open();
	}
}
