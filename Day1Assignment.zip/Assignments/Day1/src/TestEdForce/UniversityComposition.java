package TestEdForce;

import java.util.List;

public class UniversityComposition {

	private List<DepartmentComposition> departments;

	public void destroy() {
		// it's composition, when i destroy a university I also
		// destroy the departments. they cant live without university instance
		if (departments != null)
			for (DepartmentComposition d : departments)
				d.destroy();
		departments.clear();
		departments = null;
	}
}
