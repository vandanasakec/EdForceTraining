package com.ab;

public class Employee {

	public void setMarks(int i) {
		// TODO Auto-generated method stub
		
	}

	public void show() {
		// TODO Auto-generated method stub
		
	}

}
