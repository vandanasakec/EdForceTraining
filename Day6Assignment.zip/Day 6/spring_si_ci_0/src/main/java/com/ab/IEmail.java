package com.ab;

public interface IEmail {
	public void sendMail();
	
	public void recvMail();
}
