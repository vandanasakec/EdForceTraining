package com.example999.demo999.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import com.example999.demo999.model.*;


@Repository
public class BankRepository {
	List<BankAccount> baccounts;
	public BankRepository(){
		baccounts = new ArrayList<>();
	}
	
	public BankAccount saveBankAccount(BankAccount bAccount){
		baccounts.add(bAccount);
		return bAccount;
	}
	
	public Optional<BankAccount> getBankAccount(int bid){
		Optional<BankAccount> bAccount = baccounts.stream()
				.filter((e)->bid == e.getBid()).findFirst();
		
		return bAccount;
	}

	public Object deleteAccount(int bid) {
	for(BankAccount l:baccounts)
	{
		if(l.getBid()==bid)
		{
			baccounts.remove(l);
		}
	}
	return bid;
	}

	public Optional<BankAccount> updateAccount(int bid,String name) {
		Optional<BankAccount> bAccount = baccounts.stream()
				.filter((e)->bid == e.getBid()).findFirst();
		for(BankAccount l:baccounts)
		{
			if(l.getBid()==bid)
			{
l.setName(name);
			}
		}
		return bAccount;
	}
}
