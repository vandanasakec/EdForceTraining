package com;

import org.springframework.stereotype.Component;

@Component
class BankAccount{
int bid;String name;
String address;
public BankAccount(int bid, String name, String address) {
	super();
	this.bid = bid;
	this.name = name;
	this.address = address;
}
public BankAccount() {
	super();
}
public int getBid() {
	return bid;
}
public void setBid(int bid) {
	this.bid = bid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}


}
