package com;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class TestController {
	
	@GetMapping("/app/Sam")

	public String getReqParameter(@RequestParam("name") String name,@RequestParam("id") Integer id) {
return "Name : "+name+" and Id :"+id;
}

@GetMapping("/")
String met(){
return "Hello World!!!";}
@PostMapping("/create")
int createAccount(@RequestBody BankAccount baccount){
System.out.println("Received Bank Account:"+baccount);
return 0;}
}
