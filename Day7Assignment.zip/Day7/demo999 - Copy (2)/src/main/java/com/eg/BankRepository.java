package com.eg;

import org.springframework.stereotype.Repository;

@Repository
public class BankRepository {

}
