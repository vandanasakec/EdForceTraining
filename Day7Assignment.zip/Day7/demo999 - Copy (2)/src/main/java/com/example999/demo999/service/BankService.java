package com.example999.demo999.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example999.demo999.model.BankAccount;
import com.example999.demo999.repo.BankRepository;

@Service
public class BankService {
	@Autowired
	BankRepository bRepository;
	
	public BankAccount createAccount(BankAccount bAccount){
		return bRepository.saveBankAccount(bAccount);
	}
	
	public Optional<BankAccount> fetchAccount(int bid){
		return bRepository.getBankAccount(bid);
	}

	public void deleteAccount(int bid) {
		 bRepository.deleteAccount(bid);		
	}

	public Optional<BankAccount> updateAccount(int bid,String name) {
		return bRepository.updateAccount(bid,name);
	}
	
}
