package TestEdForce;

import java.util.Objects;

public class Account {
 public int accNo;
 public String accName;
@Override
public int hashCode() {
	return Objects.hash(accName, accNo);
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Account other = (Account) obj;
	return Objects.equals(accName, other.accName) && accNo == other.accNo;
}
@Override
public String toString() {
	return "Account [accNo=" + accNo + ", accName=" + accName + "]";
}
public int getAccNo() {
	return accNo;
}
public void setAccNo(int accNo) {
	this.accNo = accNo;
}
public String getAccName() {
	return accName;
}
public void setAccName(String accName) {
	this.accName = accName;
}
public Account(int accNo, String accName) {
	super();
	this.accNo = accNo;
	this.accName = accName;
}
 
 
}
