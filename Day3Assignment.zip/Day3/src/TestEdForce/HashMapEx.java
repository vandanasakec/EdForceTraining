package TestEdForce;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

class City{
	String name;
	Integer population;
	public City(String name, Integer population) {
		super();
		this.name = name;
		this.population = population;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getPopulation() {
		return population;
	}
	public void setPopulation(Integer population) {
		this.population = population;
	}
}
public class HashMapEx {
	 public static void main(String[] args) {
		 
		 HashMap<String,ArrayList<City>> map=new HashMap<>();
		 ArrayList<City> c=new ArrayList<>();
		 c.add(new City("KKR", 100));
		 c.add(new City("Haryana", 200));

		 c.add(new City("Delhi", 300));

		 c.add(new City("South", 400));

		 map.put("Banagalor", c);
		 ArrayList<City> c1=new ArrayList<>();
		 c1.add(new City("KKR1", 100));
		 c1.add(new City("Haryana1", 200));

		 c1.add(new City("Delhi1", 300));

		 c1.add(new City("South1", 400));

		 map.put("Noida", c1);
		 
		 for(Map.Entry<String, ArrayList<City>> itr:map.entrySet())
		 {
			 for(City c2:itr.getValue())
			 {
				 System.out.println("key is"+ itr.getKey() +"value is" +c2.getName()+ "population" +c2.getPopulation());
			 }
		 }
	 }
	 
}