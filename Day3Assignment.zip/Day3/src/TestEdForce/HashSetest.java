package TestEdForce;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetest {

	public static void main(String[] args) {
	
		HashSet<Account> data =new HashSet<>();
		data.add(new Account(123,"samriti"));
		data.add(new Account(123222,"samriti24"));
		data.add(new Account(123124,"samriti55"));
		data.add(new Account(123,"samriti"));
		data.add(new Account(123124,"samriti44"));
		
		Iterator<Account> itr=data.iterator();
while(itr.hasNext())
{
	System.out.println("Set elements"+itr.next());
}
	}}
