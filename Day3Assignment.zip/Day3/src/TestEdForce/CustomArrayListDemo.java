package TestEdForce;

import java.util.ArrayList;
import java.util.Collections;

public class CustomArrayListDemo<T> extends ArrayList<T>{
	
	//method to add element at the end of the list
	 private boolean addElement(T obj)
	 {
	  boolean added = false;
	int num_of_occurrences = Collections.frequency(this, obj);
	if(num_of_occurrences<2)
	  {
	   added = super.add(obj);
	  }
	  
	  return added;  
	 }
	//method to add element at a specific index, of the list
	 private boolean addElement(int index, T obj)
	 {
	  boolean added = false;
	  int num_of_occurrences = Collections.frequency(this, obj);
	if(num_of_occurrences<2)
	  {
	   super.add(index, obj);
	  }
	  
	  return added;    
	 }
	 public static void main(String[] args) {
		 CustomArrayListDemo<String> cArrayList = new CustomArrayListDemo<String>();
		  cArrayList.add("abc");
		  cArrayList.add("abc");
		  cArrayList.add("abc");
		  
		  System.out.println(cArrayList);}
}